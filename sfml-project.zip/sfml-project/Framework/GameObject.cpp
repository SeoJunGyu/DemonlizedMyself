#include "stdafx.h"
#include "GameObject.h"


GameObject::GameObject(const std::string& name)
	: name(name)
{
}

GameObject::~GameObject()
{
}
