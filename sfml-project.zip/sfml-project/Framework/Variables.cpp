#include "stdafx.h"
#include "Variables.h"

bool Variables::isDrawHitBox = false;