#include "stdafx.h"

int main()
{
    FRAMEWORK.Init(720, 1080, "DemonlizedMyself");
    FRAMEWORK.Do();
    FRAMEWORK.Release();

    return 0;
}